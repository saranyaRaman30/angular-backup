import { Component, OnInit, ViewChild } from '@angular/core';
import { SaveserviceService } from '../saveservice.service';
import { Router } from '@angular/router'; 



@Component({
  selector: 'app-templateform',
  templateUrl: './templateform.component.html',
  styleUrls: ['./templateform.component.css']
})
export class TemplateformComponent implements OnInit {
  @ViewChild('sampletemplateform', {static: false}) formValues;
  eidPattern = "^[a-zA-Z0-9]+$";
  unamePattern = "[a-zA-Z]*";
  mobnumPattern = "^((\\+91-?)|0)?[0-9]{10}$"; 
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';

  model: any = {};
  currentuser="";
  public recievedval: boolean;
  showcomp :boolean = false;
  showform :boolean = true;
  constructor(private myservice: SaveserviceService,private router: Router) { }

  ngOnInit() {
  }
  onSubmit() {
    this.myservice.getformvalues(JSON.stringify(this.model, null, 4));
    this.showcomp = true;
    this.showform = false;
    this.currentuser = this.model.role;
    this.formValues.resetForm();

  }
  recievechild(recievedval: boolean) {    
    this.recievedval = recievedval;
    this.showform = this.recievedval;
    console.log("sai" + this.recievedval );
    
  }
  goToForm(){
    console.log("saigomathiiii");
    this.router.navigate(['/form1'])
  }
  

}

