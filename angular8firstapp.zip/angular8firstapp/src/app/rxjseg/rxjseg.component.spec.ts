import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RxjsserviceService } from '../rxjsservice.service';
import { RxjsegComponent } from './rxjseg.component';

describe('RxjsegComponent', () => {
  let component: RxjsegComponent;
  let fixture: ComponentFixture<RxjsegComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RxjsegComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RxjsegComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  // it("should subscribe to get current user",() =>{
  //   user:String;
  //   spyOn(RxjsserviceService, 'editUser')
  // });
});
