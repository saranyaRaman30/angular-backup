import { Component, OnInit } from '@angular/core';
import { RxjsserviceService } from '../rxjsservice.service';
import { Observable } from 'rxjs/observable';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-rxjseg',
  templateUrl: './rxjseg.component.html',
  styleUrls: ['./rxjseg.component.css']
})
export class RxjsegComponent implements OnInit {
  currentUser:string;
  results;
  constructor(private userservice:RxjsserviceService) { }

  ngOnInit() {
    this.userservice.cast.subscribe(user=>this.currentUser = user)

    /* Example for Observable is synchronous also */
    const greetingLady$ = new Observable(observer => {
      observer.next('within synchronous observer.');
      observer.complete();
    });
    console.log('Before calling subscribe on Observable');
    greetingLady$.subscribe({
      next: console.log,
      complete: () => console.log('End of synchronous observer')
    });
    console.log('After calling subscribe on Observable (proof of being able to execute sync)');

      /* Example for Observable is asynchronous also */
    const tiredGreetingLady$ = new Observable(observer => {
      setTimeout(() => {
        observer.next('asynchronous observer');
        observer.complete();
      }, 2000);
    });    
    console.log('Before calling subscribe on Observable');    
    tiredGreetingLady$.subscribe({
      next: console.log,
      complete: () => console.log('End of asynchronous observer')
    });    
    console.log('After calling subscribe on Observable (proof of being able to execute async)');

    /*Difference Between Promises and observables */

    //using observables
    this.userservice.getdata().subscribe(res=>this.results=res);
    console.log("s+++++++++++++++++"+this.results); 

    //using promises
    this.userservice.getdata()
    .toPromise()
    .then(res => {
      this.results = res;
      console.log("getUsersWithPromise(): " + JSON.stringify(this.results));
    })
    .catch(err => { console.log(err) });

    /*promises  is only for single value */
    const numberPromise = new Promise((resolve) => {
      resolve(5);
      resolve(10);
    });  
    numberPromise.then(value => console.log("single value promise"+value));

  /*obsevable for multiple values */
    const numberObservable = new Observable((observer) => {
      observer.next(5);
      observer.next(10);
    });
    numberObservable.subscribe(value => console.log("multiple value observable"+value));
  }
} 



