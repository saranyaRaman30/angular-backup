import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-samplechild',
  templateUrl: './samplechild.component.html',
  styleUrls: ['./samplechild.component.css']
})
export class SamplechildComponent implements OnInit {
  @Input() type: string;

  constructor() { }

  ngOnInit() {
    console.log("sai")
  }

}
