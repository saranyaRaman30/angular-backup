import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TemplateformComponent } from './templateform/templateform.component';
import { RegistrationvalueComponent } from './registrationvalue/registrationvalue.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { RxjsegComponent } from './rxjseg/rxjseg.component';
import { SamplesComponent } from './samples/samples.component';
import { SamplechildComponent } from './samplechild/samplechild.component';
import { ReactiveformsComponent } from './reactiveforms/reactiveforms.component';

@NgModule({
  declarations: [
    AppComponent,
    TemplateformComponent,
    RegistrationvalueComponent,
    AdminpageComponent,
    RxjsegComponent,
    SamplesComponent,
    SamplechildComponent,
    ReactiveformsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
