import { Component, OnInit ,Output,Input, EventEmitter } from '@angular/core';
import { SaveserviceService } from '../saveservice.service'
import { RxjsserviceService } from '../rxjsservice.service';

@Component({
  selector: 'app-registrationvalue',
  templateUrl: './registrationvalue.component.html',
  styleUrls: ['./registrationvalue.component.css']
})
export class RegistrationvalueComponent implements OnInit {
  @Output() private childvalue = new EventEmitter<boolean>();
  @Input() senduserval: string;
  // username="";
  results  = [];
  resultarray = [];
  texboxname:string;
  currentUser:string;
  gobackval :boolean = false;
  showregval :boolean = true;
  showbtn :boolean = false;
  showadmin :boolean = false;
  showadminpage :boolean = false;
  constructor(private myservice: SaveserviceService,private userservice:RxjsserviceService) { }

  ngOnInit() {
    this.userservice.cast.subscribe(user=>this.currentUser = user)
    this.getDistinctRole();
   if(this.senduserval == "Admin"){
     this.showadminpage = true;
   }
   
    
  }
  getDistinctRole(){
    this.myservice.getvaluess().subscribe(
      (data : any) =>{
        this.results = JSON.parse(data);
        this.resultarray.push(this.results);
        console.log("sai" + this.resultarray);
        // if(this.senduserval == "User"){
        //   this.username = this.resultarray[0].fname;
        //   console.log("saigomathi" + this.username)
        // }
        
      },
      error =>{
        console.log("error")
      }
    );

  }
  goback(){
     this.gobackval = true;
     this.showregval = false;
     this.childvalue.emit(this.gobackval);
     window.location.reload()
  }
  showadmincomp(){
    this.showadmin = true;
  }
 /*rxjs*/
 changeUser(){
  this.userservice.editUser(this.texboxname)
 }
}
