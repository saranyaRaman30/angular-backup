import { Component, OnInit, ViewChild, ElementRef, AfterViewInit,ViewChildren,QueryList  } from '@angular/core';
import {SamplechildComponent} from '../samplechild/samplechild.component'
@Component({
  selector: 'app-samples',
  templateUrl: './samples.component.html',
  styleUrls: ['./samples.component.css']
})
export class SamplesComponent implements OnInit, AfterViewInit {
  name = 'Angular';
  @ViewChild('myButton', {static: false}) myButton: ElementRef;
  @ViewChild('primaryColorSample',{ static: true, read: SamplechildComponent })sample: SamplechildComponent;
  @ViewChildren("userName, userAge") userInfoReference: QueryList<any>;
  @ViewChildren(SamplechildComponent) alerts: QueryList<SamplechildComponent>

  constructor() { }
  ngOnInit() {
    
  }
  ngAfterViewInit() {
    console.log(this.myButton.nativeElement.innerHTML); 
    this.myButton.nativeElement.innerHTML = "Button name hanged using view child"; 
    console.log("Able to access the whole child component using view child:", this.sample.ngOnInit);
    console.log("Element List: " + this.userInfoReference.toArray());
    this.alerts.forEach(res => console.log(res));

   
  }

}
