import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {BehaviorSubject} from 'rxjs/BehaviorSubject'

@Injectable({
  providedIn: 'root'
})
export class RxjsserviceService {
  localUrl = 'https://api.myjson.com/bins/ioqt2';
  users:string[]=["gomathi","sai"];
  private user = new BehaviorSubject<string>('sai');
  cast = this.user.asObservable();
  constructor(private httpClient: HttpClient) { }
  editUser(newUser){
    this.user.next(newUser);
  }
  getdata() {
    return this.httpClient.get(this.localUrl);
  }
}
