import { TestBed } from '@angular/core/testing';

import { SaveserviceService } from './saveservice.service';

describe('SaveserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SaveserviceService = TestBed.get(SaveserviceService);
    expect(service).toBeTruthy();
  });
});
