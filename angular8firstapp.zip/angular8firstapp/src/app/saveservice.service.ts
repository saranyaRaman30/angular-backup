import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/observable';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SaveserviceService {
  savedatas: any = [];
  constructor(private httpClient: HttpClient) { }
  getformvalues(savedata: any) {
    this.savedatas = savedata;    
    console.log("formvalues are" +this.savedatas);
  }
  getvaluess() : Observable<any>{
    return of(this.savedatas);
  }
    
}
