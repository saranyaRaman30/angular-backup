import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css']
})
export class AdminpageComponent implements OnInit {
  @Input() showadminval: boolean;
  myname="saran";
  constructor() { }

  ngOnInit() {
    console.log('oninit' + this.myname + this.showadminval);
  }
  
  // ngDoCheck() {
  //   console.log('doCheck');
  //   console.log('doCheck' + this.myname + this.showadminval);
  // }

  // ngAfterContentInit() {
  //   console.log('afterContentInit');
  //   console.log('afterContentInit' + this.myname + this.showadminval);
  // }

  // ngAfterContentChecked() {
  //   console.log('afterContentChecked');
  //   console.log('afterContentChecked'+ this.myname + this.showadminval);
  // }

  // ngAfterViewInit() {
  //   console.log('afterViewInit');
  //   console.log('afterViewInit' + this.myname + this.showadminval);
  // }

  // ngAfterViewChecked() {
  //   console.log('afterViewChecked');
  //   console.log('afterViewChecked' + this.myname + this.showadminval);
  // }
 

}
