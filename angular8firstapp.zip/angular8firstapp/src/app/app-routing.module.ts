import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ReactiveformsComponent} from './reactiveforms/reactiveforms.component'


const routes: Routes = [{ path: 'form1', component: ReactiveformsComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
